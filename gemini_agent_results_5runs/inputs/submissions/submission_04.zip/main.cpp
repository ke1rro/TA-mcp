#include <cstdlib>
#include <iostream>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Expected exactly two integers\n";
        return 1;
    }
    int left = std::atoi(argv[1]);
    int right = std::atoi(argv[2]);
    if (left > right) {
        std::cerr << "Invalid range\n";
        return 2;
    }
    int total = 0;
    for (int current = left; current <= right; ++current) {
        if (current % 2 == 0) ++total;
    }
    std::cout << total << '\n';
    return 0;
}
