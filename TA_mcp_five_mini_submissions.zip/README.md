# TA-mcp: 5 tiny C++ submissions

This package is a *synthetic* mini-lab for low-token-cost MCP grading demonstrations. It is **not** the original sequential integration assignment.

1. Use `mini_assignment.md` as the complete assignment specification for **all five** reviews.
2. Feed each `submissions/submission_XX.zip` to TA-mcp **separately**; do not give the whole package to the grading agent.
3. For the course experiment, review all five submissions with the two-agent workflow, and review those same five with a single-agent baseline using the same MCP tools.
4. Collect review scores, PASS/FAIL decisions, evidence and execution traces. Measure correctness with the separate evaluator-only answer key; do not reveal the answer key to either agent.
5. Student C++ code is untrusted in general; compile and run submissions only with sandboxing and time/resource limits.

Each submission has the same neutral filename layout: `main.cpp`, `CMakeLists.txt`, `README.md`. Filenames disclose no expected outcome.
